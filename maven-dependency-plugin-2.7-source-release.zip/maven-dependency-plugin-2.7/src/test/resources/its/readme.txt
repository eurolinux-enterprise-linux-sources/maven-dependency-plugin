To create an IT test, start with the simplest example "resolve", copy and modify to simulate your condition. 
The root pom of your project(s) need to inherit from the pom.xml in this folder in order to work correctly. 
The tests should be able to be run by hand from this folder, or as part of the IT test suite. Then add a 
new test method to the DependencyPluginTest class to execute your new test.