package org.codehaus.plexus.util.interpolation;

/**
 * COPIED FROM plexus-utils-1.5.15 TO SATISFY TESTS
 *
 * @author jdcasey
 * @deprecated Use plexus-interpolation APIs instead.
 * @version $Id: ValueSource.java 12174 2010-05-16 21:04:35Z rfscholte $
 */
public interface ValueSource  extends org.codehaus.plexus.interpolation.ValueSource
{

}