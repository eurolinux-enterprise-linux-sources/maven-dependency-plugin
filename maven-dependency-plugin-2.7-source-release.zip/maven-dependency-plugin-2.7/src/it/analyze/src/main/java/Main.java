import org.apache.maven.artifact.Artifact;
import org.apache.maven.artifact.repository.metadata.Metadata;
import org.apache.maven.model.Model;

public class Main
{
    public static final String SCOPE_COMPILE = Artifact.SCOPE_COMPILE;

    public Model model = null;

    public Metadata metadata = null;
}
